package edu.utdallas.taskExecutor;


public interface TaskExecutor
{
	void addTask(Task task);
}
