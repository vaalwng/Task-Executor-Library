This project can be used to test the TaskExecutor project. 
The project contains the driver application (TaskExecutorSimpleTest.java)
and the Task implementation (SimpleTestTask.java).

Import this project into your Eclipse workspace and exercise both
your implementation during development and the exported library
jar file that will be submitted for grading. 